# Fixxd Starter Project

Includes:
- `frontend-app`: Main ticketing system
- `frontend-admin`: Admin panel for Mossync
- `backend`: Node.js/Express API
